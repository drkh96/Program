// ========================================
// main-data.js
// Central data aggregator for Chest Pain engine
// ========================================

"use strict";

(function (global) {

  // Ensure individual section arrays are loaded from:
  // personal-chest.js, cc-chest.js, hpi-chest.js,
  // ros-chest.js, background-chest.js

  const sections = [];

  if (global.CHEST_PAIN_PERSONAL) {
    sections.push(...global.CHEST_PAIN_PERSONAL);
  }
  if (global.CHEST_PAIN_CC) {
    sections.push(...global.CHEST_PAIN_CC);
  }
  if (global.CHEST_PAIN_HPI) {
    sections.push(...global.CHEST_PAIN_HPI);
  }
  if (global.CHEST_PAIN_ROS) {
    sections.push(...global.CHEST_PAIN_ROS);
  }
  if (global.CHEST_PAIN_BACKGROUND) {
    sections.push(...global.CHEST_PAIN_BACKGROUND);
  }

  global.ChestData = {
    sections
  };

})(window);
