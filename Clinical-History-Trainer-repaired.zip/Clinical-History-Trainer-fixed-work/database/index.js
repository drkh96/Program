import cases from "./cases/index.js";
import common from "./common/index.js";
import diagnoses from "./diagnoses/index.js";
import subjects from "./subjects/index.js";
import symptoms from "./symptoms/index.js";
import systems from "./systems/index.js";
import templates from "./templates/index.js";

const database = {
  cases,
  common,
  diagnoses,
  subjects,
  symptoms,
  systems,
  templates
};

export default database;