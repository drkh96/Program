import { SCORE } from "../../../../../../../engine/scoring.js";

const riskFactors = {
  id: "risk-factors",

  title: {
    ar: "عوامل الخطورة",
    en: "Risk Factors"
  },

  questions: [
    {
      id: "smoking",
      question: {
        ar: "تدخن؟",
        en: "Do you smoke?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.STRONG,
              reason: {
                ar: "التدخين عامل خطورة مهم لـ ACS.",
                en: "Smoking is a major risk factor for ACS."
              }
            },
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.STRONG,
              reason: {
                ar: "يزيد احتمال MI.",
                en: "Increases the likelihood of MI."
              }
            },
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.WEAK,
              reason: {
                ar: "قد يزيد خطر الجلطات.",
                en: "May increase thromboembolic risk."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "diabetes",
      question: {
        ar: "عندك سكري؟",
        en: "Do you have diabetes?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.STRONG,
              reason: {
                ar: "السكري يزيد خطر ACS.",
                en: "Diabetes increases ACS risk."
              }
            },
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.STRONG,
              reason: {
                ar: "السكري من أهم عوامل خطورة MI.",
                en: "Diabetes is a major risk factor for MI."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "hypertension",
      question: {
        ar: "عندك ضغط؟",
        en: "Do you have hypertension?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.MODERATE,
              reason: {
                ar: "ارتفاع الضغط يدعم أمراض الشرايين التاجية.",
                en: "Hypertension supports coronary artery disease."
              }
            },
            {
              diagnosisId: "aortic-dissection",
              score: SCORE.STRONG,
              reason: {
                ar: "ارتفاع الضغط أهم عامل خطورة لـ Aortic Dissection.",
                en: "Hypertension is the main risk factor for aortic dissection."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "previous-heart-disease",
      question: {
        ar: "صار عندك جلطة أو ذبحة أو مرض قلب قبل؟",
        en: "Previous heart disease?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.STRONG,
              reason: {
                ar: "التاريخ القلبي السابق يزيد احتمال ACS.",
                en: "Previous cardiac disease increases the likelihood of ACS."
              }
            },
            {
              diagnosisId: "heart-failure",
              score: SCORE.MODERATE,
              reason: {
                ar: "قد يكون مرتبطاً بفشل القلب.",
                en: "May be associated with heart failure."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "recent-surgery",
      question: {
        ar: "سويت عملية أو بقيت بالفراش فترة طويلة آخر شهر؟",
        en: "Recent surgery or prolonged immobilization?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "العملية أو عدم الحركة من أهم عوامل خطورة PE.",
                en: "Recent surgery or immobilization strongly supports PE."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default riskFactors;