import { SCORE } from "../../../../../../../engine/scoring.js";

const gastrointestinal = {
  id: "gastrointestinal",

  title: {
    ar: "مراجعة الجهاز الهضمي",
    en: "Gastrointestinal Review"
  },

  questions: [
    {
      id: "heartburn",
      question: {
        ar: "عندك حرقة أو حموضة؟",
        en: "Do you have heartburn or acidity?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "الحرقة والحموضة تدعم GORD.",
                en: "Heartburn strongly supports GORD."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "regurgitation",
      question: {
        ar: "يصعد أكل أو حامض للحلق؟",
        en: "Do you get acid or food regurgitation?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "Regurgitation علامة قوية للارتجاع.",
                en: "Regurgitation strongly supports reflux disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "epigastric-pain",
      question: {
        ar: "الألم يوصل أو يبدأ من فوق المعدة؟",
        en: "Does the pain start from or radiate to the epigastrium?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.MODERATE,
              reason: {
                ar: "ألم أعلى البطن قد يدعم GORD.",
                en: "Epigastric pain may support GORD."
              }
            },
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.MODERATE,
              reason: {
                ar: "MI قد يظهر كألم أعلى البطن خصوصاً Inferior MI.",
                en: "MI may present as epigastric pain, especially inferior MI."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "meal-relation",
      question: {
        ar: "الألم يزيد بعد الأكل؟",
        en: "Does the pain worsen after meals?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.STRONG,
              reason: {
                ar: "زيادة الألم بعد الأكل تدعم GORD.",
                en: "Pain after meals supports GORD."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default gastrointestinal;