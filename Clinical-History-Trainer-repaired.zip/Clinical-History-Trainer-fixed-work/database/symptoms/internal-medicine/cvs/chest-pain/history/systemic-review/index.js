import general from "./general.js";
import cardiovascular from "./cardiovascular.js";
import respiratory from "./respiratory.js";
import gastrointestinal from "./gastrointestinal.js";
import neurological from "./neurological.js";
import riskFactors from "./risk-factors.js";

const systemicReview = {
  general,
  cardiovascular,
  respiratory,
  gastrointestinal,
  neurological,
  riskFactors
};

export default systemicReview;