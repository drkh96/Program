import cardiacDrugs from "./cardiac-drugs.js";
import anticoagulants from "./anticoagulants.js";
import respiratoryDrugs from "./respiratory-drugs.js";
import gastricDrugs from "./gastric-drugs.js";

const drugHistory = {
  cardiacDrugs,
  anticoagulants,
  respiratoryDrugs,
  gastricDrugs
};

export default drugHistory;