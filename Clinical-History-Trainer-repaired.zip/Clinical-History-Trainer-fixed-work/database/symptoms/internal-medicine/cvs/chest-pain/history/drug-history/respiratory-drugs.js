import { SCORE } from "../../../../../../../engine/scoring.js";

const respiratoryDrugs = {
  id: "respiratory-drugs",

  title: {
    ar: "أدوية الجهاز التنفسي",
    en: "Respiratory Drugs"
  },

  questions: [
    {
      id: "inhalers",
      question: {
        ar: "تستخدم بخاخات للصدر؟",
        en: "Do you use inhalers?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pneumothorax",
              score: SCORE.WEAK,
              reason: {
                ar: "استخدام البخاخات قد يدل على مرض تنفسي مزمن يزيد خطر pneumothorax.",
                en: "Inhaler use may indicate chronic respiratory disease increasing pneumothorax risk."
              }
            },
            {
              diagnosisId: "pneumonia",
              score: SCORE.WEAK,
              reason: {
                ar: "الأمراض التنفسية المزمنة قد تزيد خطر العدوى الصدرية.",
                en: "Chronic respiratory disease may increase chest infection risk."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "steroids",
      question: {
        ar: "تستخدم كورتيزون لفترة طويلة؟",
        en: "Do you use long-term steroids?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pneumonia",
              score: SCORE.MODERATE,
              reason: {
                ar: "الكورتيزون المزمن يزيد خطر العدوى.",
                en: "Long-term steroids increase infection risk."
              }
            },
            {
              diagnosisId: "tuberculosis",
              score: SCORE.MODERATE,
              reason: {
                ar: "تثبيط المناعة قد يزيد خطر TB.",
                en: "Immunosuppression may increase TB risk."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default respiratoryDrugs;