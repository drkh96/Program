import { SCORE } from "../../../../../../../engine/scoring.js";

const radiation = {
  id: "radiation",

  title: {
    ar: "انتشار الألم",
    en: "Radiation"
  },

  question: {
    ar: "هل ينتشر الألم إلى مكان آخر؟",
    en: "Does the pain radiate anywhere?"
  },

  answers: [
    {
      id: "left-arm",
      ar: "إلى الذراع أو الكتف الأيسر",
      en: "Left arm / shoulder",
      effects: [
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "من العلامات الكلاسيكية لـ MI.",
            en: "Classic feature of MI."
          }
        },
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم ACS.",
            en: "Supports ACS."
          }
        },
        {
          diagnosisId: "stable-angina",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يحدث في Stable Angina.",
            en: "May occur in stable angina."
          }
        }
      ]
    },

    {
      id: "jaw-neck",
      ar: "إلى الفك أو الرقبة",
      en: "Jaw / Neck",
      effects: [
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.STRONG,
          reason: {
            ar: "انتشار الألم للفك أو الرقبة يدعم ACS.",
            en: "Supports ACS."
          }
        },
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.STRONG,
          reason: {
            ar: "شائع في MI.",
            en: "Common in MI."
          }
        }
      ]
    },

    {
      id: "back",
      ar: "إلى الظهر بين لوحي الكتف",
      en: "Back (between scapulae)",
      effects: [
        {
          diagnosisId: "aortic-dissection",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "علامة كلاسيكية لـ Aortic Dissection.",
            en: "Classic feature of aortic dissection."
          }
        }
      ]
    },

    {
      id: "epigastrium",
      ar: "إلى أعلى البطن",
      en: "Epigastrium",
      effects: [
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.MODERATE,
          reason: {
            ar: "خصوصاً Inferior MI.",
            en: "Especially inferior MI."
          }
        },
        {
          diagnosisId: "gord",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يحدث في GORD.",
            en: "May occur in GORD."
          }
        }
      ]
    },

    {
      id: "none",
      ar: "لا ينتشر",
      en: "No radiation",
      effects: [
        {
          diagnosisId: "costochondritis",
          score: SCORE.WEAK,
          reason: {
            ar: "يدعم السبب العضلي.",
            en: "Supports musculoskeletal pain."
          }
        },
        {
          diagnosisId: "muscle-injury",
          score: SCORE.WEAK,
          reason: {
            ar: "يدعم إصابة عضلية.",
            en: "Supports muscle injury."
          }
        }
      ]
    }
  ]
};

export default radiation;