import { SCORE } from "../../../../../../../engine/scoring.js";

const site = {
  id: "site",

  title: {
    ar: "مكان الألم",
    en: "Site"
  },

  question: {
    ar: "وين مكان الألم؟",
    en: "Where is the pain?"
  },

  answers: [
    {
      id: "central",
      ar: "مركز الصدر",
      en: "Central / retrosternal",
      effects: [
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.STRONG,
          reason: {
            ar: "ألم مركز الصدر يدعم نقص تروية القلب.",
            en: "Central chest pain supports myocardial ischemia."
          }
        },
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.STRONG,
          reason: {
            ar: "الألم خلف القص ممكن يكون علامة على MI.",
            en: "Retrosternal pain may suggest MI."
          }
        },
        {
          diagnosisId: "pericarditis",
          score: SCORE.MODERATE,
          reason: {
            ar: "ألم مركز الصدر ممكن يحدث في pericarditis.",
            en: "Central chest pain may occur in pericarditis."
          }
        },
        {
          diagnosisId: "gord",
          score: SCORE.WEAK,
          reason: {
            ar: "الألم خلف القص ممكن يكون من ارتجاع المريء.",
            en: "Retrosternal pain can occur in GORD."
          }
        }
      ]
    },

    {
      id: "peripheral",
      ar: "جانب الصدر",
      en: "Peripheral chest pain",
      effects: [
        {
          diagnosisId: "pleurisy",
          score: SCORE.STRONG,
          reason: {
            ar: "ألم جانب الصدر يدعم ألم منشؤه البلورا.",
            en: "Peripheral chest pain supports pleuritic origin."
          }
        },
        {
          diagnosisId: "pneumonia",
          score: SCORE.MODERATE,
          reason: {
            ar: "ألم جانب الصدر قد يحدث مع pneumonia.",
            en: "Peripheral chest pain may occur with pneumonia."
          }
        },
        {
          diagnosisId: "pneumothorax",
          score: SCORE.MODERATE,
          reason: {
            ar: "الألم الجانبي المفاجئ ممكن يدل على pneumothorax.",
            en: "Sudden peripheral chest pain may suggest pneumothorax."
          }
        },
        {
          diagnosisId: "costochondritis",
          score: SCORE.MODERATE,
          reason: {
            ar: "الألم الجانبي أو الموضعي ممكن يكون musculoskeletal.",
            en: "Localized peripheral pain may be musculoskeletal."
          }
        }
      ]
    }
  ]
};

export default site;