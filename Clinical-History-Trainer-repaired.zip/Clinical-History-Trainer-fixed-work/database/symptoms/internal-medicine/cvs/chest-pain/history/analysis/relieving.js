import { SCORE } from "../../../../../../../engine/scoring.js";

const relieving = {
  id: "relieving",

  title: {
    ar: "العوامل التي تخفف الألم",
    en: "Relieving Factors"
  },

  question: {
    ar: "شنو الشي اللي يخفف الألم؟",
    en: "What relieves the pain?"
  },

  answers: [
    {
      id: "rest",
      ar: "الراحة",
      en: "Rest",
      effects: [
        {
          diagnosisId: "stable-angina",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "التحسن بالراحة يدعم Stable Angina.",
            en: "Relief with rest supports stable angina."
          }
        }
      ]
    },

    {
      id: "gtn",
      ar: "حبوب تحت اللسان (GTN)",
      en: "GTN",
      effects: [
        {
          diagnosisId: "stable-angina",
          score: SCORE.STRONG,
          reason: {
            ar: "التحسن مع GTN يدعم الذبحة الصدرية.",
            en: "Relief with GTN supports angina."
          }
        },
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.WEAK,
          reason: {
            ar: "قد يتحسن جزئياً في ACS.",
            en: "May partially improve in ACS."
          }
        }
      ]
    },

    {
      id: "lean-forward",
      ar: "الانحناء للأمام",
      en: "Leaning forward",
      effects: [
        {
          diagnosisId: "pericarditis",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "علامة مميزة لـ Pericarditis.",
            en: "Classic feature of pericarditis."
          }
        }
      ]
    },

    {
      id: "antacid",
      ar: "مضاد الحموضة",
      en: "Antacid",
      effects: [
        {
          diagnosisId: "gord",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "التحسن مع مضاد الحموضة يدعم GORD.",
            en: "Relief with antacid supports GORD."
          }
        }
      ]
    },

    {
      id: "nothing",
      ar: "ما يخف بأي شيء",
      en: "Nothing relieves it",
      effects: [
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.STRONG,
          reason: {
            ar: "الألم المستمر غير المستجيب يدعم MI.",
            en: "Persistent pain supports MI."
          }
        },
        {
          diagnosisId: "aortic-dissection",
          score: SCORE.MODERATE,
          reason: {
            ar: "يدعم Aortic Dissection.",
            en: "Supports aortic dissection."
          }
        }
      ]
    }
  ]
};

export default relieving;