import { SCORE } from "../../../../../../../engine/scoring.js";

const gastricDrugs = {
  id: "gastric-drugs",

  title: {
    ar: "أدوية المعدة",
    en: "Gastric Drugs"
  },

  questions: [
    {
      id: "ppi",
      question: {
        ar: "تاخذ علاج حموضة مثل Omeprazole أو Pantoprazole؟",
        en: "Do you take acid-reducing drugs like omeprazole or pantoprazole?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.STRONG,
              reason: {
                ar: "استخدام PPI قد يدل على ارتجاع أو حموضة مزمنة.",
                en: "PPI use may indicate chronic reflux or acidity."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "nsaids",
      question: {
        ar: "تاخذ مسكنات مثل Ibuprofen أو Diclofenac بكثرة؟",
        en: "Do you frequently take NSAIDs like ibuprofen or diclofenac?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.MODERATE,
              reason: {
                ar: "كثرة NSAIDs قد تسبب ألم معدة أو ارتجاع يشبه ألم الصدر.",
                en: "Frequent NSAID use may cause gastric pain or reflux mimicking chest pain."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default gastricDrugs;