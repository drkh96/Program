import { SCORE } from "../../../../../../../engine/scoring.js";

const cardiacDrugs = {
  id: "cardiac-drugs",

  title: {
    ar: "أدوية القلب",
    en: "Cardiac Drugs"
  },

  questions: [
    {
      id: "aspirin",
      question: {
        ar: "تاخذ أسبرين؟",
        en: "Do you take aspirin?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.MODERATE,
              reason: {
                ar: "استخدام الأسبرين قد يدل على مرض شرايين تاجية سابق.",
                en: "Aspirin use may indicate previous coronary artery disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "statin",
      question: {
        ar: "تاخذ علاج للدهون مثل Atorvastatin؟",
        en: "Do you take a statin such as atorvastatin?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.MODERATE,
              reason: {
                ar: "استخدام الستاتين قد يدل على خطورة قلبية أو مرض شرايين سابق.",
                en: "Statin use may indicate cardiovascular risk or previous coronary disease."
              }
            },
            {
              diagnosisId: "stable-angina",
              score: SCORE.WEAK,
              reason: {
                ar: "الستاتين شائع عند مرضى الذبحة أو أمراض الشرايين.",
                en: "Statins are common in patients with angina or coronary disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "gtn",
      question: {
        ar: "تستخدم حبوب تحت اللسان للذبحة GTN؟",
        en: "Do you use GTN under the tongue?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "stable-angina",
              score: SCORE.STRONG,
              reason: {
                ar: "استخدام GTN سابقاً يدعم وجود ذبحة صدرية.",
                en: "Previous GTN use supports angina."
              }
            },
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.WEAK,
              reason: {
                ar: "قد يكون لدى المريض مرض شرايين تاجية سابق.",
                en: "The patient may have previous coronary artery disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "antihypertensive",
      question: {
        ar: "تاخذ علاج للضغط؟",
        en: "Do you take antihypertensive medication?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.MODERATE,
              reason: {
                ar: "علاج الضغط يدل على وجود HTN وهو عامل خطورة لـ ACS.",
                en: "Antihypertensive use indicates HTN, a risk factor for ACS."
              }
            },
            {
              diagnosisId: "aortic-dissection",
              score: SCORE.MODERATE,
              reason: {
                ar: "ارتفاع الضغط عامل خطورة مهم لـ Aortic Dissection.",
                en: "Hypertension is a major risk factor for aortic dissection."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default cardiacDrugs;