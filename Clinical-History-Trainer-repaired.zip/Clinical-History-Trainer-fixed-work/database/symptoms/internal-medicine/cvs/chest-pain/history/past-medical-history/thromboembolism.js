import { SCORE } from "../../../../../../../engine/scoring.js";

const thromboembolism = {
  id: "thromboembolism",

  title: {
    ar: "تاريخ الجلطات",
    en: "Thromboembolic History"
  },

  questions: [
    {
      id: "previous-dvt-pe",
      question: {
        ar: "صار عندك جلطة بالساق أو جلطة رئوية قبل؟",
        en: "Previous DVT or PE?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "وجود DVT أو PE سابق يدعم بقوة PE.",
                en: "Previous DVT or PE strongly supports pulmonary embolism."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "recent-surgery-immobility",
      question: {
        ar: "سويت عملية أو بقيت بالفراش فترة طويلة مؤخراً؟",
        en: "Recent surgery or prolonged immobilization?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "العملية أو قلة الحركة من أهم عوامل خطورة PE.",
                en: "Recent surgery or immobilization is a major risk factor for PE."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "long-travel",
      question: {
        ar: "سافرت سفر طويل أو قعدت مدة طويلة بدون حركة؟",
        en: "Long travel or prolonged sitting?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.STRONG,
              reason: {
                ar: "السفر الطويل أو الجلوس الطويل يزيد خطر DVT/PE.",
                en: "Long travel or prolonged sitting increases DVT/PE risk."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "cancer",
      question: {
        ar: "عندك سرطان أو علاج كيمياوي؟",
        en: "Cancer or chemotherapy?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.STRONG,
              reason: {
                ar: "السرطان يزيد قابلية التخثر ويدعم PE.",
                en: "Cancer increases thrombosis risk and supports PE."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default thromboembolism;