import { SCORE } from "../../../../../../../engine/scoring.js";

const neurological = {
  id: "neurological",

  title: {
    ar: "مراجعة الجهاز العصبي",
    en: "Neurological Review"
  },

  questions: [
    {
      id: "syncope",
      question: {
        ar: "صار عندك إغماء؟",
        en: "Have you had syncope?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "aortic-dissection",
              score: SCORE.MODERATE,
              reason: {
                ar: "الإغماء مع ألم صدري شديد قد يحدث في Aortic Dissection.",
                en: "Syncope with severe chest pain may occur in aortic dissection."
              }
            },
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.MODERATE,
              reason: {
                ar: "الإغماء قد يحدث في Massive PE.",
                en: "Syncope may occur in massive PE."
              }
            },
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.MODERATE,
              reason: {
                ar: "الإغماء قد يحدث بسبب اضطراب نظم مرافق لـ MI.",
                en: "Syncope may occur due to arrhythmia in MI."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "weakness",
      question: {
        ar: "حسيت بضعف مفاجئ بجهة من الجسم؟",
        en: "Have you had sudden weakness on one side of the body?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.WEAK,
              reason: {
                ar: "الضعف المفاجئ قد يدل على مرض وعائي مشترك مع IHD.",
                en: "Sudden weakness may suggest vascular disease associated with IHD."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "dizziness",
      question: {
        ar: "عندك دوخة شديدة؟",
        en: "Do you have severe dizziness?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.WEAK,
              reason: {
                ar: "الدوخة قد ترافق MI خصوصاً مع انخفاض الضغط أو اضطراب النظم.",
                en: "Dizziness may accompany MI, especially with hypotension or arrhythmia."
              }
            },
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.WEAK,
              reason: {
                ar: "الدوخة قد تحدث في PE الشديد.",
                en: "Dizziness may occur in severe PE."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default neurological;