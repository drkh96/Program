import { SCORE } from "../../../../../../../engine/scoring.js";

const general = {
  id: "general",

  title: {
    ar: "الأعراض العامة",
    en: "General Symptoms"
  },

  questions: [
    {
      id: "fever",
      question: {
        ar: "عندك حرارة؟",
        en: "Do you have fever?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pneumonia",
              score: SCORE.STRONG,
              reason: {
                ar: "الحرارة تدعم Pneumonia.",
                en: "Fever supports pneumonia."
              }
            },
            {
              diagnosisId: "pericarditis",
              score: SCORE.MODERATE,
              reason: {
                ar: "الحرارة ممكن ترافق Pericarditis.",
                en: "Fever may occur with pericarditis."
              }
            },
            {
              diagnosisId: "myocarditis",
              score: SCORE.MODERATE,
              reason: {
                ar: "الحرارة قد تدعم Myocarditis خصوصاً بعد عدوى فيروسية.",
                en: "Fever may support myocarditis, especially after viral illness."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "fatigue",
      question: {
        ar: "تحس بتعب عام أو خمول؟",
        en: "Do you feel general fatigue?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.WEAK,
              reason: {
                ar: "التعب العام قد يرافق MI، خصوصاً عند كبار السن أو مرضى السكري.",
                en: "Fatigue may accompany MI, especially in elderly or diabetic patients."
              }
            },
            {
              diagnosisId: "heart-failure",
              score: SCORE.MODERATE,
              reason: {
                ar: "التعب العام قد يحدث في Heart Failure.",
                en: "Fatigue may occur in heart failure."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "weight-loss",
      question: {
        ar: "صار عندك نزول وزن غير مقصود؟",
        en: "Have you had unintentional weight loss?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "lung-cancer",
              score: SCORE.STRONG,
              reason: {
                ar: "نزول الوزن غير المقصود قد يدعم Lung Cancer.",
                en: "Unintentional weight loss may support lung cancer."
              }
            },
            {
              diagnosisId: "tuberculosis",
              score: SCORE.STRONG,
              reason: {
                ar: "نزول الوزن قد يدعم TB.",
                en: "Weight loss may support TB."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "night-sweats",
      question: {
        ar: "يصير عندك تعرق ليلي؟",
        en: "Do you have night sweats?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "tuberculosis",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "التعرق الليلي يدعم TB.",
                en: "Night sweats strongly support TB."
              }
            },
            {
              diagnosisId: "lung-cancer",
              score: SCORE.MODERATE,
              reason: {
                ar: "التعرق الليلي مع نزول وزن قد يدعم malignancy.",
                en: "Night sweats with weight loss may support malignancy."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default general;