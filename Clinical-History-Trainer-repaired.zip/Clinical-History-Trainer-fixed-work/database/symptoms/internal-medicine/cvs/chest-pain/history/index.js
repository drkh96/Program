// ===============================
// Chest Pain History Flow
// ===============================

import analysis from "./analysis/index.js";

import systemicReview from "./systemic-review/index.js";

import pastMedicalHistory from "./past-medical-history/index.js";

import drugHistory from "./drug-history/index.js";

import pastSurgicalHistory from "./past-surgical-history.js";

import familyHistory from "./family-history.js";

import socialHistory from "./social-history.js";

const history = {
  initialFlow: [
    {
      id: "analysis",
      title: {
        ar: "تحليل ألم الصدر",
        en: "Chest Pain Analysis"
      },
      questions: analysis
    }
  ],

  conditionalSections: {

    // ===============================
    // Systemic Review
    // ===============================

    "systemic-review.general": systemicReview.general,

    "systemic-review.cardiovascular": systemicReview.cardiovascular,

    "systemic-review.respiratory": systemicReview.respiratory,

    "systemic-review.gastrointestinal": systemicReview.gastrointestinal,

    "systemic-review.neurological": systemicReview.neurological,

    "systemic-review.risk-factors": systemicReview.riskFactors,

    // ===============================
    // Past Medical History
    // ===============================

    "past-medical-history.cardiovascular":
      pastMedicalHistory.cardiovascular,

    "past-medical-history.respiratory":
      pastMedicalHistory.respiratory,

    "past-medical-history.gastrointestinal":
      pastMedicalHistory.gastrointestinal,

    "past-medical-history.thromboembolism":
      pastMedicalHistory.thromboembolism,

    // ===============================
    // Drug History
    // ===============================

    "drug-history.cardiac-drugs":
      drugHistory.cardiacDrugs,

    "drug-history.anticoagulants":
      drugHistory.anticoagulants,

    "drug-history.respiratory-drugs":
      drugHistory.respiratoryDrugs,

    "drug-history.gastric-drugs":
      drugHistory.gastricDrugs,

    // ===============================
    // Other History
    // ===============================

    "past-surgical-history":
      pastSurgicalHistory,

    "family-history":
      familyHistory,

    "social-history":
      socialHistory
  }
};

export default history;