import { SCORE } from "../../../../../../../engine/scoring.js";

const associatedSymptoms = {
  id: "associated-symptoms",

  title: {
    ar: "الأعراض المصاحبة",
    en: "Associated Symptoms"
  },

  question: {
    ar: "شنو الأعراض اللي صارت ويا الألم؟",
    en: "What symptoms are associated with the pain?"
  },

  answers: [
    {
      id: "sweating",
      ar: "تعرق",
      en: "Sweating",
      effects: [
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.STRONG,
          reason: {
            ar: "التعرق يدعم ACS.",
            en: "Supports ACS."
          }
        },
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.STRONG,
          reason: {
            ar: "شائع في MI.",
            en: "Common in MI."
          }
        }
      ]
    },

    {
      id: "nausea-vomiting",
      ar: "غثيان أو تقيؤ",
      en: "Nausea / Vomiting",
      effects: [
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.STRONG,
          reason: {
            ar: "خصوصاً Inferior MI.",
            en: "Especially inferior MI."
          }
        },
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.MODERATE,
          reason: {
            ar: "يدعم ACS.",
            en: "Supports ACS."
          }
        }
      ]
    },

    {
      id: "dyspnea",
      ar: "ضيق نفس",
      en: "Shortness of breath",
      effects: [
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يحدث في ACS.",
            en: "May occur in ACS."
          }
        },
        {
          diagnosisId: "heart-failure",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم Heart Failure.",
            en: "Supports heart failure."
          }
        },
        {
          diagnosisId: "pulmonary-embolism",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم PE.",
            en: "Supports pulmonary embolism."
          }
        },
        {
          diagnosisId: "pneumothorax",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم Pneumothorax.",
            en: "Supports pneumothorax."
          }
        }
      ]
    },

    {
      id: "cough",
      ar: "كحة",
      en: "Cough",
      effects: [
        {
          diagnosisId: "pneumonia",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم Pneumonia.",
            en: "Supports pneumonia."
          }
        },
        {
          diagnosisId: "pleurisy",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يحدث في Pleurisy.",
            en: "May occur in pleurisy."
          }
        }
      ]
    },

    {
      id: "fever",
      ar: "حرارة",
      en: "Fever",
      effects: [
        {
          diagnosisId: "pneumonia",
          score: SCORE.STRONG,
          reason: {
            ar: "الحرارة تدعم Pneumonia.",
            en: "Fever supports pneumonia."
          }
        },
        {
          diagnosisId: "pericarditis",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد ترافق Pericarditis.",
            en: "May accompany pericarditis."
          }
        }
      ]
    },

    {
      id: "palpitations",
      ar: "خفقان",
      en: "Palpitations",
      effects: [
        {
          diagnosisId: "atrial-fibrillation",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم AF.",
            en: "Supports atrial fibrillation."
          }
        },
        {
          diagnosisId: "supraventricular-tachycardia",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم SVT.",
            en: "Supports SVT."
          }
        }
      ]
    },

    {
      id: "syncope",
      ar: "إغماء",
      en: "Syncope",
      effects: [
        {
          diagnosisId: "aortic-dissection",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يحدث في Aortic Dissection.",
            en: "May occur in aortic dissection."
          }
        },
        {
          diagnosisId: "pulmonary-embolism",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يحدث في Massive PE.",
            en: "May occur in massive pulmonary embolism."
          }
        },
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يحدث بسبب اضطرابات النظم.",
            en: "May occur due to arrhythmias."
          }
        }
      ]
    },

    {
      id: "none",
      ar: "لا يوجد",
      en: "None",
      effects: []
    }
  ]
};

export default associatedSymptoms;