import { SCORE } from "../../../../../../../engine/scoring.js";

const course = {
  id: "course",

  title: {
    ar: "تطور الألم",
    en: "Course"
  },

  question: {
    ar: "شلون صار الألم مع الوقت؟",
    en: "How has the pain progressed?"
  },

  answers: [
    {
      id: "getting-worse",
      ar: "يزيد تدريجياً",
      en: "Progressively worsening",
      effects: [
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.STRONG,
          reason: {
            ar: "تفاقم الألم يدعم ACS.",
            en: "Progressive worsening supports ACS."
          }
        },
        {
          diagnosisId: "unstable-angina",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "صفة نموذجية لـ Unstable Angina.",
            en: "Typical of unstable angina."
          }
        }
      ]
    },

    {
      id: "constant",
      ar: "ثابت",
      en: "Constant",
      effects: [
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.STRONG,
          reason: {
            ar: "الألم الثابت المستمر يدعم MI.",
            en: "Constant pain supports MI."
          }
        },
        {
          diagnosisId: "aortic-dissection",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يكون ثابتاً وشديداً.",
            en: "May be constant and severe."
          }
        }
      ]
    },

    {
      id: "intermittent",
      ar: "يجي ويروح",
      en: "Intermittent",
      effects: [
        {
          diagnosisId: "stable-angina",
          score: SCORE.STRONG,
          reason: {
            ar: "صفة شائعة في Stable Angina.",
            en: "Typical of stable angina."
          }
        },
        {
          diagnosisId: "gord",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يكون متقطعاً.",
            en: "May be intermittent."
          }
        }
      ]
    },

    {
      id: "improving",
      ar: "يتحسن",
      en: "Improving",
      effects: [
        {
          diagnosisId: "costochondritis",
          score: SCORE.WEAK,
          reason: {
            ar: "التحسن التدريجي يدعم السبب الحميد.",
            en: "Gradual improvement supports benign causes."
          }
        }
      ]
    }
  ]
};

export default course;