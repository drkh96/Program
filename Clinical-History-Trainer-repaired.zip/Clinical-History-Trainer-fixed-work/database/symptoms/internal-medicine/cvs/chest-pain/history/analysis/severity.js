import { SCORE } from "../../../../../../../engine/scoring.js";

const severity = {
  id: "severity",

  title: {
    ar: "شدة الألم",
    en: "Severity"
  },

  question: {
    ar: "إذا تقيم الألم من 1 إلى 10، شكد تعطيه؟",
    en: "If you rate the pain from 1 to 10, how severe is it?"
  },

  answers: [
    {
      id: "mild",
      ar: "خفيف (1-3)",
      en: "Mild (1-3)",
      effects: [
        {
          diagnosisId: "costochondritis",
          score: SCORE.MODERATE,
          reason: {
            ar: "الألم الخفيف يدعم الأسباب العضلية.",
            en: "Mild pain supports musculoskeletal causes."
          }
        },
        {
          diagnosisId: "muscle-injury",
          score: SCORE.MODERATE,
          reason: {
            ar: "يدعم إصابة عضلية.",
            en: "Supports muscle injury."
          }
        }
      ]
    },

    {
      id: "moderate",
      ar: "متوسط (4-6)",
      en: "Moderate (4-6)",
      effects: [
        {
          diagnosisId: "stable-angina",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يحدث في Stable Angina.",
            en: "May occur in stable angina."
          }
        },
        {
          diagnosisId: "gord",
          score: SCORE.WEAK,
          reason: {
            ar: "قد يكون متوسط الشدة.",
            en: "May be moderate."
          }
        }
      ]
    },

    {
      id: "severe",
      ar: "شديد (7-10)",
      en: "Severe (7-10)",
      effects: [
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.STRONG,
          reason: {
            ar: "الألم الشديد يدعم MI.",
            en: "Severe pain supports MI."
          }
        },
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.STRONG,
          reason: {
            ar: "قد يكون شديداً في ACS.",
            en: "May be severe in ACS."
          }
        },
        {
          diagnosisId: "aortic-dissection",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "الألم الشديد جداً من العلامات الكلاسيكية لـ Aortic Dissection.",
            en: "Extremely severe pain is classic for aortic dissection."
          }
        },
        {
          diagnosisId: "pulmonary-embolism",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يكون شديداً.",
            en: "May be severe."
          }
        },
        {
          diagnosisId: "pneumothorax",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يكون شديداً.",
            en: "May be severe."
          }
        }
      ]
    }
  ]
};

export default severity;