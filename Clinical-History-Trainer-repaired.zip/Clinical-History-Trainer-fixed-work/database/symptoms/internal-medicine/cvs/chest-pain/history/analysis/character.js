import { SCORE } from "../../../../../../../engine/scoring.js";

const character = {
  id: "character",

  title: {
    ar: "طبيعة الألم",
    en: "Character"
  },

  question: {
    ar: "شلون تحس الألم؟",
    en: "How would you describe the pain?"
  },

  answers: [
    {
      id: "crushing",
      ar: "ضاغط / عاصر",
      en: "Crushing / Tight",
      effects: [
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "الألم الضاغط من الصفات الكلاسيكية لـ ACS.",
            en: "Crushing pain is a classic feature of ACS."
          }
        },
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "الألم العاصر القوي يدعم MI.",
            en: "Severe crushing pain supports MI."
          }
        },
        {
          diagnosisId: "stable-angina",
          score: SCORE.MODERATE,
          reason: {
            ar: "الألم الضاغط مع الجهد قد يدل على Stable Angina.",
            en: "Tight pain with exertion may suggest stable angina."
          }
        }
      ]
    },

    {
      id: "burning",
      ar: "حارق",
      en: "Burning",
      effects: [
        {
          diagnosisId: "gord",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "الألم الحارق خلف القص يدعم GORD.",
            en: "Burning retrosternal pain supports GORD."
          }
        },
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.NEGATIVE,
          reason: {
            ar: "الألم الحارق أقل نموذجية لـ ACS.",
            en: "Burning pain is less typical of ACS."
          }
        }
      ]
    },

    {
      id: "sharp",
      ar: "حاد مثل الطعنة",
      en: "Sharp / Stabbing",
      effects: [
        {
          diagnosisId: "pleurisy",
          score: SCORE.STRONG,
          reason: {
            ar: "الألم الحاد يشاهد كثيراً في أمراض البلورا.",
            en: "Sharp pain commonly occurs in pleuritic disease."
          }
        },
        {
          diagnosisId: "pneumothorax",
          score: SCORE.STRONG,
          reason: {
            ar: "الألم الحاد المفاجئ يدعم Pneumothorax.",
            en: "Sudden sharp pain supports pneumothorax."
          }
        },
        {
          diagnosisId: "pulmonary-embolism",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يكون ألم PE حاداً ويزداد مع التنفس.",
            en: "PE pain may be sharp and pleuritic."
          }
        }
      ]
    },

    {
      id: "tearing",
      ar: "مثل التمزق",
      en: "Tearing",
      effects: [
        {
          diagnosisId: "aortic-dissection",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "الألم الممزق من العلامات الكلاسيكية لـ Aortic Dissection.",
            en: "Tearing pain strongly supports aortic dissection."
          }
        }
      ]
    },

    {
      id: "aching",
      ar: "وجع مستمر",
      en: "Aching",
      effects: [
        {
          diagnosisId: "costochondritis",
          score: SCORE.MODERATE,
          reason: {
            ar: "الألم الوجعي المستمر قد يكون من جدار الصدر.",
            en: "Aching pain may be musculoskeletal."
          }
        },
        {
          diagnosisId: "muscle-injury",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يكون الألم الوجعي بسبب إصابة عضلية.",
            en: "Aching pain may suggest muscle injury."
          }
        }
      ]
    }
  ]
};

export default character;