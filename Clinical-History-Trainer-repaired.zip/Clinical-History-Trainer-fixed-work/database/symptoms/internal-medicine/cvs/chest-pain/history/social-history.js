import { SCORE } from "../../../../../../engine/scoring.js";

const socialHistory = {
  id: "social-history",

  title: {
    ar: "التاريخ الاجتماعي",
    en: "Social History"
  },

  questions: [
    {
      id: "smoking",
      question: {
        ar: "تدخن؟ وإذا نعم، من شكد وكم سيگارة باليوم؟",
        en: "Do you smoke? If yes, for how long and how many per day?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.STRONG,
              reason: {
                ar: "التدخين عامل خطورة قوي لـ ACS.",
                en: "Smoking is a strong risk factor for ACS."
              }
            },
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.STRONG,
              reason: {
                ar: "التدخين يزيد خطر MI.",
                en: "Smoking increases MI risk."
              }
            },
            {
              diagnosisId: "lung-cancer",
              score: SCORE.STRONG,
              reason: {
                ar: "التدخين يدعم احتمال Lung Cancer.",
                en: "Smoking supports lung cancer risk."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "alcohol",
      question: {
        ar: "تشرب كحول؟",
        en: "Do you drink alcohol?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.MODERATE,
              reason: {
                ar: "الكحول قد يزيد الارتجاع والحموضة.",
                en: "Alcohol may worsen reflux symptoms."
              }
            },
            {
              diagnosisId: "atrial-fibrillation",
              score: SCORE.WEAK,
              reason: {
                ar: "الكحول قد يرتبط باضطراب النظم مثل AF.",
                en: "Alcohol may be associated with arrhythmias such as AF."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "occupation",
      question: {
        ar: "شنو شغلك؟ وهل تتعرض لغبار أو مواد كيمياوية؟",
        en: "What is your occupation? Any dust or chemical exposure?"
      },
      answers: [
        {
          id: "dust-exposure",
          ar: "تعرض لغبار أو مواد كيمياوية",
          en: "Dust or chemical exposure",
          effects: [
            {
              diagnosisId: "pneumonia",
              score: SCORE.WEAK,
              reason: {
                ar: "التعرض المهني قد يدعم مشاكل تنفسية.",
                en: "Occupational exposure may support respiratory disease."
              }
            },
            {
              diagnosisId: "lung-cancer",
              score: SCORE.MODERATE,
              reason: {
                ar: "بعض التعرضات المهنية تزيد خطر Lung Cancer.",
                en: "Some occupational exposures increase lung cancer risk."
              }
            }
          ]
        },
        {
          id: "no-risk",
          ar: "لا يوجد تعرض مهم",
          en: "No significant exposure",
          effects: []
        }
      ]
    },

    {
      id: "activity",
      question: {
        ar: "حركتك قليلة لو تمارس رياضة؟",
        en: "Are you sedentary or physically active?"
      },
      answers: [
        {
          id: "sedentary",
          ar: "حركة قليلة",
          en: "Sedentary",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.MODERATE,
              reason: {
                ar: "قلة الحركة تزيد خطر أمراض الشرايين.",
                en: "Sedentary lifestyle increases coronary risk."
              }
            },
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.WEAK,
              reason: {
                ar: "قلة الحركة قد تزيد خطر الجلطات.",
                en: "Immobility may increase thromboembolic risk."
              }
            }
          ]
        },
        {
          id: "active",
          ar: "نشط / يمارس رياضة",
          en: "Physically active",
          effects: []
        }
      ]
    }
  ]
};

export default socialHistory;