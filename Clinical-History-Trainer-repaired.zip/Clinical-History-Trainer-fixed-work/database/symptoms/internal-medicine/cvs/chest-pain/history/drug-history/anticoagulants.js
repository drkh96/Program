import { SCORE } from "../../../../../../../engine/scoring.js";

const anticoagulants = {
  id: "anticoagulants",

  title: {
    ar: "مميعات الدم",
    en: "Anticoagulants / Antiplatelets"
  },

  questions: [
    {
      id: "warfarin-doac",
      question: {
        ar: "تاخذ مميع دم مثل Warfarin أو Apixaban أو Rivaroxaban؟",
        en: "Do you take anticoagulants like warfarin, apixaban, or rivaroxaban?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "atrial-fibrillation",
              score: SCORE.STRONG,
              reason: {
                ar: "استخدام مميع الدم قد يدل على AF سابق.",
                en: "Anticoagulant use may indicate previous AF."
              }
            },
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.MODERATE,
              reason: {
                ar: "قد يدل على تاريخ سابق لـ DVT/PE.",
                en: "May indicate previous DVT/PE."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "clopidogrel",
      question: {
        ar: "تاخذ Clopidogrel أو دواء للشبكات؟",
        en: "Do you take clopidogrel or medication after stenting?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.STRONG,
              reason: {
                ar: "Clopidogrel قد يدل على PCI أو ACS سابق.",
                en: "Clopidogrel may indicate previous PCI or ACS."
              }
            },
            {
              diagnosisId: "stable-angina",
              score: SCORE.MODERATE,
              reason: {
                ar: "قد يدل على مرض شرايين تاجية سابق.",
                en: "May indicate previous coronary artery disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default anticoagulants;