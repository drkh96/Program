function investigations(patient = {}, state = {}) {
  const top = state.sortedDDx?.[0]?.id;

  const common = [
    "ECG",
    "Cardiac troponin",
    "Chest X-ray",
    "Full blood count",
    "Urea and electrolytes",
    "Random blood glucose"
  ];

  const plans = {
    "acute-coronary-syndrome": [
      "Immediate 12-lead ECG",
      "Serial cardiac troponin",
      "FBC, U&E, RBS",
      "Lipid profile",
      "Coagulation profile",
      "Chest X-ray",
      "Echocardiography",
      "Coronary angiography"
    ],

    "myocardial-infarction": [
      "Immediate 12-lead ECG",
      "Cardiac troponin",
      "FBC, U&E, RBS",
      "Coagulation profile",
      "Chest X-ray",
      "Echocardiography",
      "Urgent coronary angiography"
    ],

    "aortic-dissection": [
      "ECG",
      "Chest X-ray",
      "FBC, U&E, coagulation profile",
      "Cross-match blood",
      "CT angiography of the aorta",
      "Echocardiography if unstable"
    ],

    "pulmonary-embolism": [
      "ECG",
      "Chest X-ray",
      "D-dimer if low/intermediate probability",
      "CT pulmonary angiography",
      "ABG",
      "FBC, U&E, coagulation profile",
      "Leg Doppler ultrasound if DVT suspected"
    ],

    "pneumothorax": [
      "Chest X-ray",
      "Bedside ultrasound if available",
      "ABG if hypoxic or unstable"
    ],

    "pneumonia": [
      "Chest X-ray",
      "FBC",
      "CRP",
      "Sputum culture if productive cough",
      "Blood culture if febrile or septic",
      "Oxygen saturation / ABG if severe"
    ],

    "gord": [
      "ECG first if chest pain to exclude cardiac cause",
      "Trial of PPI if no red flags",
      "Upper GI endoscopy if alarm symptoms or persistent symptoms"
    ],

    "costochondritis": [
      "Usually clinical diagnosis",
      "ECG if cardiac cause must be excluded",
      "Chest X-ray if trauma or respiratory signs"
    ]
  };

  return {
    title: "Investigations",
    diagnosisId: top || null,
    items: plans[top] || common
  };
}

export default investigations;