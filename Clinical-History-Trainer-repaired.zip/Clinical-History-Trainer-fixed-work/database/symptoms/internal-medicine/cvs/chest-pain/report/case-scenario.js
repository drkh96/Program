function getText(value) {
  if (!value) return "";
  if (typeof value === "string") return value;
  return value.en || value.ar || "";
}

function groupAnswersByQuestion(answers = []) {
  const grouped = {};

  answers.forEach(item => {
    if (!item.questionId) return;

    grouped[item.questionId] = item;
  });

  return grouped;
}

function caseScenario(patient = {}, state = {}) {
  const grouped = groupAnswersByQuestion(state.answers);
  const top = state.sortedDDx?.[0];

  const age = patient.age ? `${patient.age}-year-old` : "A";
  const gender = patient.gender || "patient";
  const occupation = patient.occupation ? ` ${patient.occupation}` : "";

  const site = grouped.site?.answer;
  const character = grouped.character?.answer;
  const onset = grouped.onset?.answer;
  const radiation = grouped.radiation?.answer;
  const duration = grouped.duration?.answer;
  const course = grouped.course?.answer;
  const severity = grouped.severity?.answer;
  const aggravating = grouped.aggravating?.answer;
  const relieving = grouped.relieving?.answer;
  const associated = grouped["associated-symptoms"]?.answer;

  const story = [];

  story.push(
    `${age} ${gender}${occupation ? "," + occupation + "," : ""} presented with chest pain.`
  );

  const painDescription = [];

  if (site) painDescription.push(`located in the ${getText(site).toLowerCase()}`);
  if (character) painDescription.push(`described as ${getText(character).toLowerCase()}`);
  if (onset) painDescription.push(`which started ${getText(onset).toLowerCase()}`);
  if (duration) painDescription.push(`and lasted for ${getText(duration).toLowerCase()}`);

  if (painDescription.length) {
    story.push(`The pain was ${painDescription.join(", ")}.`);
  }

  if (radiation && radiation.id !== "none") {
    story.push(`It radiated to the ${getText(radiation).toLowerCase()}.`);
  }

  if (aggravating) {
    story.push(`The pain was aggravated by ${getText(aggravating).toLowerCase()}.`);
  }

  if (relieving) {
    story.push(`It was relieved by ${getText(relieving).toLowerCase()}.`);
  }

  if (associated && associated.id !== "none") {
    story.push(`It was associated with ${getText(associated).toLowerCase()}.`);
  }

  if (course) {
    story.push(`The course of the pain was ${getText(course).toLowerCase()}.`);
  }

  if (severity) {
    story.push(`The pain severity was reported as ${getText(severity).toLowerCase()}.`);
  }

  const positives = state.answers
    ?.filter(item => item.answer?.id === "yes")
    ?.map(item => getText(item.questionTitle))
    ?.filter(Boolean);

  if (positives?.length) {
    story.push(`Relevant positive history included ${positives.join(", ")}.`);
  }

  if (top) {
    story.push(`Based on the collected history, the most likely diagnosis was ${top.id}.`);
  }

  return {
    title: "Case Scenario",
    diagnosisId: top?.id || null,
    text: story.join(" "),
    ddx: state.sortedDDx || []
  };
}

export default caseScenario;