function examination(patient = {}, state = {}) {
  const top = state.sortedDDx?.[0]?.id;

  const common = [
    "Assess general appearance: distress, pallor, sweating.",
    "Check vital signs: BP in both arms, pulse, respiratory rate, temperature, SpO₂.",
    "Look for signs of shock or heart failure."
  ];

  const plans = {
    "acute-coronary-syndrome": [
      ...common,
      "Cardiovascular examination: JVP, heart sounds, murmurs, peripheral pulses.",
      "Respiratory examination: basal crackles suggesting pulmonary edema.",
      "Check for peripheral edema."
    ],

    "myocardial-infarction": [
      ...common,
      "Cardiovascular examination: heart sounds, murmurs, signs of complications.",
      "Respiratory examination for pulmonary edema.",
      "Assess peripheral perfusion."
    ],

    "aortic-dissection": [
      ...common,
      "Measure BP in both arms.",
      "Check pulse deficit between limbs.",
      "Auscultate for aortic regurgitation murmur.",
      "Perform focused neurological examination."
    ],

    "pulmonary-embolism": [
      ...common,
      "Respiratory examination: signs of tachypnea, pleural rub, reduced air entry.",
      "Examine legs for DVT: unilateral swelling, calf tenderness.",
      "Look for cyanosis or signs of right heart strain."
    ],

    "pneumothorax": [
      ...common,
      "Respiratory examination: reduced chest movement.",
      "Percussion: hyper-resonance.",
      "Auscultation: reduced or absent breath sounds.",
      "Look for tracheal deviation if tension pneumothorax suspected."
    ],

    "pneumonia": [
      ...common,
      "Respiratory examination: crackles, bronchial breathing.",
      "Check for dullness to percussion.",
      "Look for signs of consolidation."
    ],

    "gord": [
      "General examination usually normal.",
      "Abdominal examination: epigastric tenderness.",
      "Cardiorespiratory examination to exclude serious causes."
    ],

    "costochondritis": [
      "General examination usually normal.",
      "Palpate chest wall for localized tenderness.",
      "Check if pain is reproducible by pressure or movement.",
      "Cardiorespiratory examination to exclude serious causes."
    ]
  };

  return {
    title: "Examination",
    diagnosisId: top || null,
    items: plans[top] || common
  };
}

export default examination;