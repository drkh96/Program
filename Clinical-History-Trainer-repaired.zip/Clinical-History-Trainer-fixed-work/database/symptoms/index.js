import chestPain from "./internal-medicine/cvs/chest-pain/index.js";

const symptoms = {
  internalMedicine: {
    cvs: {
      chestPain
    }
  }
};

export default symptoms;
