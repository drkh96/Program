import emergency from "./emergency.js";
import medications from "./medications.js";
import reperfusion from "./reperfusion.js";
import admission from "./admission.js";
import discharge from "./discharge.js";

const management = {
  emergency,
  medications,
  reperfusion,
  admission,
  discharge
};

export default management;