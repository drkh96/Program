import bedside from "./bedside.js";
import laboratory from "./laboratory.js";
import imaging from "./imaging.js";
import specialTests from "./special-tests.js";

const investigations = {
  bedside,
  laboratory,
  imaging,
  specialTests
};

export default investigations;