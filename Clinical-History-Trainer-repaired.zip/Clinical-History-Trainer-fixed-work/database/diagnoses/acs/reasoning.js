export default function reasoning() { return []; }
