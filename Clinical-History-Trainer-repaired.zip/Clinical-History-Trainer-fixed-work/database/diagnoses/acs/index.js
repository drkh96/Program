import history from "./history/index.js";
import examination from "./examination/index.js";
import investigations from "./investigations/index.js";
import management from "./management/index.js";
import complications from "./complications/index.js";
import reasoning from "./reasoning.js";

const acs = {
  id: "acute-coronary-syndrome",

  name: {
    ar: "متلازمة الشريان التاجي الحادة",
    en: "Acute Coronary Syndrome"
  },

  history,
  examination,
  investigations,
  management,
  complications,
  reasoning
};

export default acs;