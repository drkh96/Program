const subjects = {
  internalMedicine: {
    id: "internal-medicine",
    name: {
      ar: "الباطنية",
      en: "Internal Medicine"
    },
    available: true,
    modules: ["chest-pain"]
  },
  surgery: {
    id: "surgery",
    name: {
      ar: "الجراحة",
      en: "Surgery"
    },
    available: false,
    modules: []
  },
  pediatrics: {
    id: "pediatrics",
    name: {
      ar: "الأطفال",
      en: "Pediatrics"
    },
    available: false,
    modules: []
  },
  obgyn: {
    id: "obgyn",
    name: {
      ar: "النسائية والتوليد",
      en: "Obstetrics & Gynecology"
    },
    available: false,
    modules: []
  }
};

export default subjects;
