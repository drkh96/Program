# Clinical History Trainer / MedAid

## How to run

```bash
npm start
```

Then open:

```text
http://localhost:8080
```

## What works now

- Home page.
- Theme switching:
  - Default
  - Boy Mode
  - Princess Mode
- Internal Medicine subject page.
- Chest Pain interview trainer.
- Live DDx scoring.
- Clinical reasoning panel.
- Generated clinical report:
  - Case scenario
  - Examination
  - Investigations
  - Management
  - Complications if available from diagnosis database

## Notes

Only Internal Medicine / CVS / Chest Pain is connected currently. Other subjects are kept as Coming Soon until their databases are added.
