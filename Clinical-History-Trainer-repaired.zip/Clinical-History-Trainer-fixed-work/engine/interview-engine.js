import { applyEffects, sortDDx } from "./scoring.js";

export function createInterviewState(initialDDx) {
  const ddx = structuredClone(initialDDx);

  return {
    ddx,
    sortedDDx: sortDDx(ddx),
    answers: [],
    nextSections: []
  };
}

export function answerQuestion(state, question, answer, logic) {
  const updatedDDx = applyEffects(state.ddx, answer.effects || []);
  const sortedDDx = sortDDx(updatedDDx);
  const nextSections = logic ? getNextSections(sortedDDx, logic) : [];

  return {
    ...state,
    ddx: updatedDDx,
    sortedDDx,
    nextSections,

    answers: [
      ...state.answers,
      {
        questionId: question.id,
        questionTitle: question.title || question.question,
        answer
      }
    ]
  };
}

export function getNextSections(sortedDDx, logic) {
  const sections = new Set();

  logic.nextSections.forEach(pathway => {
    const isActive = sortedDDx.some(diagnosis =>
      pathway.when.includes(diagnosis.id) &&
      diagnosis.score >= pathway.minScore
    );

    if (isActive) {
      pathway.show.forEach(section => sections.add(section));
    }
  });

  return Array.from(sections);
}