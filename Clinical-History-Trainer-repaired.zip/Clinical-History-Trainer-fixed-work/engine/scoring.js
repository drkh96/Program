export const SCORE = {
  VERY_STRONG: 10,
  STRONG: 7,
  MODERATE: 5,
  WEAK: 2,
  VERY_WEAK: 1,
  NEGATIVE: -5
};

export function applyEffect(ddx, diagnosisId, score, reason) {
  if (!ddx[diagnosisId]) return ddx;

  ddx[diagnosisId].score += score;

  if (reason && !ddx[diagnosisId].reasons.includes(reason)) {
    ddx[diagnosisId].reasons.push(reason);
  }

  return ddx;
}

export function applyEffects(ddx, effects = []) {
  effects.forEach(effect => {
    applyEffect(
      ddx,
      effect.diagnosisId,
      effect.score,
      effect.reason
    );
  });

  return ddx;
}

export function sortDDx(ddx) {
  return Object.entries(ddx)
    .sort((a, b) => b[1].score - a[1].score)
    .map(([id, data]) => ({
      id,
      score: data.score,
      reasons: data.reasons
    }));
}

export function topDiagnosis(ddx) {
  return sortDDx(ddx)[0] || null;
}