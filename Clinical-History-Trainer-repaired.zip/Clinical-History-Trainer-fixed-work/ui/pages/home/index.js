export function renderHomePage() {
  return `
    <main class="home-page">
      <section class="hero-card">
        <div>
          <p class="eyebrow">Clinical History Trainer</p>
          <h1>MedAid</h1>
          <p class="subtitle">Smart history taking with live DDx, clinical reasoning, and exam-ready reports.</p>
        </div>

        <div class="theme-buttons">
          <button type="button" onclick="applyTheme('default')">Default ⚕️</button>
          <button type="button" onclick="applyTheme('boy')">Boy Mode 💙</button>
          <button type="button" onclick="applyTheme('girl')">Princess Mode 🌸✨</button>
        </div>
      </section>

      <section class="subject-grid" aria-label="Subjects">
        <button type="button" class="subject-card active" onclick="openSubject('internal-medicine')">
          <span class="subject-icon">🫀</span>
          <strong>Internal Medicine</strong>
          <small>Chest pain trainer جاهز</small>
        </button>

        <button type="button" class="subject-card disabled" onclick="showComingSoon('Surgery')">
          <span class="subject-icon">🩺</span>
          <strong>Surgery</strong>
          <small>Coming soon</small>
        </button>

        <button type="button" class="subject-card disabled" onclick="showComingSoon('Pediatrics')">
          <span class="subject-icon">🧸</span>
          <strong>Pediatrics</strong>
          <small>Coming soon</small>
        </button>

        <button type="button" class="subject-card disabled" onclick="showComingSoon('Obstetrics & Gynecology')">
          <span class="subject-icon">🌸</span>
          <strong>Obstetrics & Gynecology</strong>
          <small>Coming soon</small>
        </button>
      </section>

      <section class="quick-start-card">
        <div>
          <h2>Start available case</h2>
          <p>Internal Medicine / CVS / Chest Pain</p>
        </div>
        <button type="button" onclick="startInterview('chest-pain')">Start Chest Pain Case →</button>
      </section>
    </main>
  `;
}

export function renderSubjectPage() {
  return `
    <main class="home-page">
      <section class="hero-card compact">
        <button type="button" class="back-btn" onclick="goHome()">← Home</button>
        <p class="eyebrow">Internal Medicine</p>
        <h1>Choose a case</h1>
        <p class="subtitle">حالياً الموديول المربوط هو Chest Pain، وبعدين نضيف باقي الأعراض والمواد.</p>
      </section>

      <section class="module-grid">
        <button type="button" class="module-card active" onclick="startInterview('chest-pain')">
          <span>🫀 CVS</span>
          <strong>Chest Pain</strong>
          <small>History taking + DDx + report</small>
        </button>

        <button type="button" class="module-card disabled" onclick="showComingSoon('Shortness of breath')">
          <span>🫁 Respiratory</span>
          <strong>Shortness of Breath</strong>
          <small>Coming soon</small>
        </button>

        <button type="button" class="module-card disabled" onclick="showComingSoon('Abdominal pain')">
          <span>🍽️ GIT</span>
          <strong>Abdominal Pain</strong>
          <small>Coming soon</small>
        </button>
      </section>
    </main>
  `;
}
