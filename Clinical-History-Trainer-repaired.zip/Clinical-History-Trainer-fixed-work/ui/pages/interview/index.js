function getText(value) {
  if (!value) return "";
  if (typeof value === "string") return value;
  return value.en || value.ar || "";
}

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function flattenFlow(flow = []) {
  return flow.flatMap(section =>
    (section.questions || []).map(question => ({
      sectionId: section.id,
      sectionTitle: section.title,
      question
    }))
  );
}

export function getCurrentQuestionIndex(items, answeredQuestionIds) {
  const index = items.findIndex(item => !answeredQuestionIds.has(item.question.id));
  return index === -1 ? Math.max(items.length - 1, 0) : index;
}

function renderProgress(answeredCount, totalCount) {
  const percent = totalCount ? Math.round((answeredCount / totalCount) * 100) : 0;

  return `
    <div class="progress-block">
      <div class="progress-meta">
        <span>Progress</span>
        <strong>${answeredCount}/${totalCount}</strong>
      </div>
      <div class="progress-track">
        <div class="progress-fill" style="width:${percent}%"></div>
      </div>
    </div>
  `;
}

function renderDDx(ddx = []) {
  const visible = ddx.slice(0, 8);

  if (!visible.length) {
    return `<p class="muted">No differential diagnosis yet.</p>`;
  }

  return `
    <div class="ddx-list">
      ${visible.map((item, index) => `
        <article class="ddx-item ${index === 0 ? "top" : ""}">
          <div>
            <strong>${escapeHtml(item.id.replaceAll("-", " "))}</strong>
            <small>${item.reasons?.length || 0} reason(s)</small>
          </div>
          <span>${item.score}</span>
        </article>
      `).join("")}
    </div>
  `;
}

function renderReasoning(reasoning = []) {
  const visible = reasoning.slice(0, 5);

  if (!visible.length) {
    return `<p class="muted">اختار جواب حتى تظهر أسباب التشخيص.</p>`;
  }

  return visible.map(item => `
    <details class="reason-card">
      <summary>${escapeHtml(item.diagnosisId.replaceAll("-", " "))} <span>${item.score}</span></summary>
      <ul>
        ${(item.reasons || []).slice(0, 5).map(reason => `
          <li>${escapeHtml(getText(reason))}</li>
        `).join("")}
      </ul>
    </details>
  `).join("");
}

function renderAnswerButton(question, answer) {
  const english = escapeHtml(answer.en || answer.id);
  const arabic = escapeHtml(answer.ar || "");

  return `
    <button type="button" class="answer-btn" onclick="answerCurrentQuestion('${question.id}', '${answer.id}')">
      <strong>${english}</strong>
      ${arabic ? `<span>${arabic}</span>` : ""}
    </button>
  `;
}

function renderQuestionCard(currentItem, answeredCount, totalCount) {
  if (!currentItem) {
    return `
      <section class="question-card done-card">
        <h2>Interview completed ✅</h2>
        <p>كل الأسئلة الحالية خلصت. افتح التقرير حتى تشوف السيناريو والفحص والتحاليل والعلاج.</p>
        <button type="button" class="primary-btn" onclick="showReport()">Show Report</button>
      </section>
    `;
  }

  const question = currentItem.question;

  return `
    <section class="question-card">
      ${renderProgress(answeredCount, totalCount)}

      <p class="section-label">${escapeHtml(getText(currentItem.sectionTitle))}</p>
      <h2>${escapeHtml(getText(question.question))}</h2>
      <p class="question-subtitle">${escapeHtml(getText(question.title))}</p>

      <div class="answer-grid">
        ${(question.answers || []).map(answer => renderAnswerButton(question, answer)).join("")}
      </div>

      <div class="question-actions">
        <button type="button" class="ghost-btn" onclick="skipCurrentQuestion('${question.id}')">Skip question</button>
        <button type="button" class="ghost-btn" onclick="resetInterview()">Reset</button>
      </div>
    </section>
  `;
}

function renderAnswersTimeline(answers = []) {
  if (!answers.length) {
    return `<p class="muted">ماكو أجوبة بعد.</p>`;
  }

  return `
    <div class="timeline">
      ${answers.slice(-8).reverse().map(item => `
        <article>
          <small>${escapeHtml(getText(item.questionTitle))}</small>
          <strong>${escapeHtml(getText(item.answer))}</strong>
        </article>
      `).join("")}
    </div>
  `;
}

export function renderInterviewPage({ controller, module, completed = false }) {
  const state = controller.getState();
  const flow = controller.getFlow();
  const items = flattenFlow(flow);
  const answeredQuestionIds = new Set(state.answers.map(answer => answer.questionId));
  const currentIndex = getCurrentQuestionIndex(items, answeredQuestionIds);
  const currentItem = completed ? null : items[currentIndex];
  const answeredCount = answeredQuestionIds.size;
  const totalCount = items.length;

  return `
    <main class="interview-page">
      <header class="interview-topbar">
        <div>
          <button type="button" class="back-btn" onclick="goHome()">← Home</button>
          <p class="eyebrow">${escapeHtml(getText(module.name))}</p>
          <h1>History Taking Trainer</h1>
        </div>
        <div class="topbar-actions">
          <button type="button" onclick="showReport()">Report</button>
          <button type="button" onclick="resetInterview()">Restart</button>
        </div>
      </header>

      <section class="interview-layout">
        <aside class="side-panel">
          <h3>Live DDx</h3>
          ${renderDDx(controller.getDDx())}

          <h3>Reasoning</h3>
          ${renderReasoning(controller.getReasoning())}
        </aside>

        <div class="main-panel">
          ${renderQuestionCard(currentItem, answeredCount, totalCount)}
        </div>

        <aside class="side-panel">
          <h3>Last answers</h3>
          ${renderAnswersTimeline(state.answers)}
        </aside>
      </section>
    </main>
  `;
}

function renderListBlock(title, data) {
  if (!data) return "";

  if (Array.isArray(data.items)) {
    return `
      <section class="report-block">
        <h3>${escapeHtml(data.title || title)}</h3>
        <ul>${data.items.map(item => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
      </section>
    `;
  }

  if (typeof data === "object") {
    return `
      <section class="report-block">
        <h3>${escapeHtml(data.title?.en || data.title || title)}</h3>
        ${Object.values(data).map(value => {
          if (!value || !Array.isArray(value.items)) return "";
          return `
            <h4>${escapeHtml(value.title?.en || "Section")}</h4>
            <ul>${value.items.map(item => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
          `;
        }).join("")}
      </section>
    `;
  }

  return "";
}

export function renderReportPage({ controller, module }) {
  const state = controller.getState();
  const report = controller.getReport({});
  const topDiagnosis = state.sortedDDx?.[0];

  return `
    <main class="interview-page report-page">
      <header class="interview-topbar">
        <div>
          <button type="button" class="back-btn" onclick="backToInterview()">← Interview</button>
          <p class="eyebrow">${escapeHtml(getText(module.name))}</p>
          <h1>Clinical Report</h1>
        </div>
        <div class="topbar-actions">
          <button type="button" onclick="copyReportText()">Copy Report</button>
          <button type="button" onclick="resetInterview()">Restart</button>
        </div>
      </header>

      <section class="report-shell" id="reportText">
        <section class="report-block highlight">
          <h2>Most likely diagnosis</h2>
          <p><strong>${escapeHtml(topDiagnosis?.id?.replaceAll("-", " ") || "Not enough data")}</strong></p>
          <p class="muted">Score: ${topDiagnosis?.score ?? 0}</p>
        </section>

        <section class="report-block">
          <h3>${escapeHtml(report.caseScenario?.title || "Case Scenario")}</h3>
          <p>${escapeHtml(report.caseScenario?.text || "No scenario generated yet.")}</p>
        </section>

        ${renderListBlock("Examination", report.examination)}
        ${renderListBlock("Investigations", report.investigations)}
        ${renderListBlock("Management", report.management)}
        ${renderListBlock("Complications", report.complications)}
      </section>
    </main>
  `;
}
