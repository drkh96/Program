// ===============================
// MedAid Application
// ===============================

import {
  loadSavedTheme,
  applyTheme,
  getCurrentTheme
} from "./theme-engine.js";

import { renderHomePage, renderSubjectPage } from "../pages/home/index.js";
import { renderInterviewPage, renderReportPage, flattenFlow } from "../pages/interview/index.js";

import chestPain from "../../database/symptoms/internal-medicine/cvs/chest-pain/index.js";
import InterviewController from "../../engine/interview-controller.js";

const modules = {
  "chest-pain": chestPain
};

const appState = {
  view: "home",
  activeSubject: null,
  activeModuleId: null,
  activeModule: null,
  controller: null
};

function root() {
  return document.getElementById("app");
}

function getAnsweredQuestionIds() {
  if (!appState.controller) return new Set();
  return new Set(appState.controller.getState().answers.map(answer => answer.questionId));
}

function isInterviewCompleted() {
  if (!appState.controller) return false;
  const items = flattenFlow(appState.controller.getFlow());
  const answeredIds = getAnsweredQuestionIds();
  return items.length > 0 && items.every(item => answeredIds.has(item.question.id));
}

function render() {
  if (appState.view === "subject") {
    root().innerHTML = renderSubjectPage(appState.activeSubject);
    return;
  }

  if (appState.view === "interview" && appState.controller && appState.activeModule) {
    root().innerHTML = renderInterviewPage({
      controller: appState.controller,
      module: appState.activeModule,
      completed: isInterviewCompleted()
    });
    return;
  }

  if (appState.view === "report" && appState.controller && appState.activeModule) {
    root().innerHTML = renderReportPage({
      controller: appState.controller,
      module: appState.activeModule
    });
    return;
  }

  root().innerHTML = renderHomePage();
}

function goHome() {
  appState.view = "home";
  appState.activeSubject = null;
  render();
}

function openSubject(subjectId) {
  if (subjectId !== "internal-medicine") {
    showComingSoon(subjectId);
    return;
  }

  appState.view = "subject";
  appState.activeSubject = subjectId;
  render();
}

function startInterview(moduleId = "chest-pain") {
  const selectedModule = modules[moduleId];

  if (!selectedModule) {
    showComingSoon(moduleId);
    return;
  }

  appState.activeModuleId = moduleId;
  appState.activeModule = selectedModule;
  appState.controller = new InterviewController(selectedModule);
  appState.view = "interview";
  render();
}

function findQuestion(questionId) {
  if (!appState.controller) return null;
  const items = flattenFlow(appState.controller.getFlow());
  return items.find(item => item.question.id === questionId)?.question || null;
}

function answerCurrentQuestion(questionId, answerId) {
  if (!appState.controller) return;

  const question = findQuestion(questionId);
  if (!question) return;

  const answeredIds = getAnsweredQuestionIds();
  if (answeredIds.has(question.id)) return;

  const answer = (question.answers || []).find(item => item.id === answerId);
  if (!answer) return;

  appState.controller.answer(question, answer);
  appState.view = "interview";
  render();
}

function skipCurrentQuestion(questionId) {
  if (!appState.controller) return;

  const question = findQuestion(questionId);
  if (!question) return;

  const answeredIds = getAnsweredQuestionIds();
  if (answeredIds.has(question.id)) return;

  appState.controller.answer(question, {
    id: "skipped",
    en: "Skipped",
    ar: "تخطي",
    effects: []
  });

  appState.view = "interview";
  render();
}

function showReport() {
  if (!appState.controller) return;
  appState.view = "report";
  render();
}

function backToInterview() {
  if (!appState.controller) return;
  appState.view = "interview";
  render();
}

function resetInterview() {
  if (!appState.activeModuleId) {
    startInterview("chest-pain");
    return;
  }

  startInterview(appState.activeModuleId);
}

async function copyReportText() {
  const report = document.getElementById("reportText")?.innerText || "";
  if (!report.trim()) return;

  try {
    await navigator.clipboard.writeText(report);
    alert("Report copied ✅");
  } catch (error) {
    console.warn("Clipboard failed", error);
    const textarea = document.createElement("textarea");
    textarea.value = report;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
    alert("Report copied ✅");
  }
}

function showComingSoon(name = "This section") {
  alert(`${name} بعده غير مربوط. حالياً Chest Pain يشتغل.`);
}

function initializeApp() {
  loadSavedTheme();
  render();

  console.log("MedAid Started");
  console.log("Current Theme:", getCurrentTheme());
}

// ===============================
// Global Functions used by HTML templates
// ===============================

window.applyTheme = applyTheme;
window.goHome = goHome;
window.openSubject = openSubject;
window.startInterview = startInterview;
window.answerCurrentQuestion = answerCurrentQuestion;
window.skipCurrentQuestion = skipCurrentQuestion;
window.showReport = showReport;
window.backToInterview = backToInterview;
window.resetInterview = resetInterview;
window.copyReportText = copyReportText;
window.showComingSoon = showComingSoon;

initializeApp();
